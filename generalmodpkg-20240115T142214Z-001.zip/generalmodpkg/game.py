import random
def rockpaperscissor():
    while True:
        option = ['Rock','Paper','Scissors']
        computer = random.choice(option)
        gamesystem = random.choice(option)
        print("Lets Play the Game")
        choose = input("Please Enter any one option from (Rock/Paper/Scissors : \n")
        if gamesystem == choose and gamesystem == computer:
            print("Game Tied , Both of You Selected {}".format(gamesystem))
            ch = input("Do you Want to Quit the Game(Yes/No) : ")
            if ch =='Yes':
                exit()
            else:
                continue
        elif gamesystem==choose and gamesystem!=computer:
            print("Congratulation ! You Win \n Computer Selected : {} ".format(computer))
            ch = input("Do you Want to Quit the Game(Yes/No) : ")
            if ch =='Yes':
                exit()
            else:
                continue
            
        else:
            print("Oops ! You Loose")
            ch = input("Do you Want to Quit the Game(Yes/No) : ")
            if ch =='Yes':
                exit()
            else:
                continue

def guessnumber():
    import random as r
    g=r.randint(1,10)
    s=1
    while True:
        n=int(input('Guess 1 Number between 1 to 10 :- '))
        if n>10:
            print('You are out of Range , Try Again!')
        elif n<=10 or n>=1:
            if n==g:
                print('\nCongratulations ! You won the game in',s,'Attempts')
                print('The Number was',g)
                ch = input("Do you Want to Quit the Game(Yes/No) : ")
                if ch =='Yes':
                    exit()
                else:
                    continue
            else:
                s=s+1
                print('Oops ..... Try Again!')
                ch = input("Do you Want to Quit the Game(Yes/No) : ")
                if ch =='Yes':
                    exit()
                else:
                    continue


def game():
    print("---------------------------------------------------------------------------------")
    print("\t \t \t  MAIN MENU  \t \t \t")
    print("---------------------------------------------------------------------------------")
    print("1. Rock - Paper - Scissor\n")
    print("2. Guessing Number\n")
    print("3. Exit\n")
    choice = int(input("To Play your Favourite Enter your Choice : \n"))
    if(choice==1):
        rockpaperscissor()
    elif(choice==2):
        guessnumber()
    else :
        exit()


