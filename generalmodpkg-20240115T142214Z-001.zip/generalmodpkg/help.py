import webbrowser as wb
import os
def help():
        print("Modules available in the package are listed below : ")
        print("1. basicpkg")
        print("2. Calender")
        print("3. game")
        print("4. randomequation")
        print("5. pywhatkitlib")
        print("6. pyttsx3lib")
        print("To Know the detail how to use this module plz visit our help section portal")
        ch = input("Select [Yes/No]/[yes/no]/[YES/NO]/[Y/N] /[y/n] to visit our Help Section Portal,If No it will exit the file :  \n ")
        if ch=='Yes' or ch=='yes' or ch=='YES' or ch=='Y' or ch=='y':
                wb.open_new_tab('https://sites.google.com/view/generalmodpkg-helpcenter/home')
        elif ch=='No' or ch=='no' or ch=='NO' or ch=='N' or ch=='n':
            exit()

