def evenodd(n):
	if n%2==0:
		print(n,"is even number")
	else:
		print(n,"is odd number")
def max2num(a,b):
	if a>b:
		print(a,"is greater than",b)
	else:
		print(b,"is greater than",a)
def max3num(a,b,c):
	if a>b and a>c:
		print(a,"is greater than",b,"and",c)
	elif b>a and b>c:
		print(b,"is greater than",a,"and",c)
	else:
		print(c,"is greater than",b,"and",a)
def min2num(a,b):
	if a<b:
		print(a,"is smaller than",b)
	else:
		print(b,"is smaller than",a)
def min3num(a,b,c):
	if a<b and a<c:
		print(a,"is smaller than",b,"and",c)
	elif b<a and b<c:
		print(b,"is smaller than",a,"and",c)
	else:
		print(c,"is smaller than",b,"and",a)
def leapyearfinder(yr):
        if yr % 4 == 0:
                print(yr,"is a leap year")
        elif yr % 400 == 0:
                print(yr,"is a leap year")
        else:
                print(yr,"is not a leap year")
def add2num(a,b):
        print("Addtion of ",a,"and",b,"is : ",a+b)

def add3num(a,b,c):
        print("Addtion of ",a,",",b," and ",c," is : ",a+b+c)
def printf(argument):
	print(argument)
def sub2num(a,b):
	print("Subtraction of ",a,"and",b,"is : ",a-b)
def sub3num(a,b,c):
        print("Addtion of ",a,",",b," and ",c," is : ",a-b-c)
def mul2num(a,b):
	print("Multiplication of ",a,"and",b,"is : ",a*b)
def mul3num(a,b,c):
        print("Multiplication of ",a,",",b," and ",c," is : ",a*b*c)
def sumnnum(n):
	i=1
	sum=0
	while(i<=n):
	    sum=sum+i
	    i+=1
	print("The sum of 1 to ",n," natural number is : ",sum)

def posnegchecker(num):
        if num>0:
                print(num,"is positive number")
        elif(num==0):
                print("Oops ! You entered Zero Number")
        else:
                print(num,"is negative number")


def strtoupper(str):
        j=str.swapcase()
        print(j)
def strtolower(str):
        j=str.swapcase()
        print(j)

def int_tostr(n):
        str(n)
        print(n)

def str_toint(str):
        int(str)
        print(str)
        print("Sometimes String to Integer Conversion is not possible, it will show Error")

def float_tostr(flt):
        str(flt)
        print(flt)
def float_toint(n):
        int(n)
        print(n)
def int_tofloat(n):
        float(n)
        print(n)
def str_tofloat(str):
        float(str)
        print(str)
        print("Sometimes String to Integer Conversion is not possible, it will show Error")
def primenum(num):
        if num > 1:
                for i in range(2,num):
                        if (num % i) == 0:
                                print(num,"is not a prime number")
                                print(i,"times",num//i,"is",num)
                                break
                        else:
                                print(num,"is a prime number")
        else:
                print(num,"is not a prime number")
def armstrong(num):
        sum = 0
        temp = num
        while temp > 0:
                digit = temp % 10
                sum += digit ** 3
                temp //= 10
        if num == sum:
                print(num,"is an Armstrong number")
        else:
                print(num,"is not an Armstrong number")
def factorial(num):
        factorial = 1
        if num < 0:
                print("Sorry, factorial does not exist for negative numbers")
        elif num == 0:
                print("The factorial of 0 is 1")
        else:
                for i in range(1,num + 1):
                        factorial = factorial*i
                print("The factorial of",num,"is",factorial)
def palindromenum(num):
        temp = num
        rev = 0
        while(num > 0):
                dig = num%10
                rev = rev*10+dig
                num = num//10
        if(temp==rev):
                print(temp," is a palindrome!")
        else:
                print(temp," isn't a palindrome!")
def palindromestr(string):
        if(string==string[::-1]):
                print(string," is a Palindrome String")
        else:
                print(string,"Not a Palindrome String")
