from pywhatkit import *
def searchinfo():
        try:
                searchresult=input("Search Wikipedia : ")
                info(searchresult)
        except:
                print("No Internet Connection")
def sendmsg(phno):
        try:
                msg=input("Enter Message to send : ")
                print("Note : Message Time Should be like 14,30 format means 14 hr 30min")
                timehr = int(input("Enter Hour in (24 hour format e.g. 14) : \n"))
                timemin = int(input("Enter Minute in (60 minutes format e.g. 14:30 ) : \n"))
                pywhatkit.sendwhatmsg(phno,msg,timehr,timemin)
        except:
                print("Network Error : No Internet Access")
def playytvid(search):
        try:
                playonyt(search)
        except:
                print("Internet is not stable or network error occured")
def google(result):
        try:
                search(result)
        except:
                print("No Internet")
	
