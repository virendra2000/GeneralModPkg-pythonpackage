# Author: Virendra Kalwar
# Contact: email-vkalwar132000@gmail.com

"""A package for parsing, handling, and generating email messages."""


__all__ = [
    'basicpkg',
    'game',
    'randomequation',
    'Calender',
    'help',
    'pywhatkitlib',
    'pyttsx3lib',
    ]
