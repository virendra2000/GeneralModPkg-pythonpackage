from pyttsx3 import *
def text2speech(text):
	engine = init()
	engine.say(text)
	engine.runAndWait()
